# Free/Public Assets:
As for free/public assets, you are granted permission to use, modify, and redistribute them, provided that appropriate credit is attributed to me. Under no circumstances are you permitted to sell any of these assets or any parts thereof. Displaying my assets in streams, videos, social media posts, etc., is acceptable, with the condition that proper credit is given.

# Official Communication and Support:
For all inquiries and support-related matters, please utilize my Discord server as the sole official channel of communication.
https://discord.gg/6AcpahXKQu